"""
The DataProcessor class translates numbers into graphical representations.
Alain Chen, CJ Phillips, Brett Woods
Created: Oct 17th, 2014
Last Edited: Dec 14th, 2014

We hereby certify that the program below represents our work 
and the design, content, and logic was completed without outside assistance.
"""

import Data as dt
import Projections as Proj

class DataProcessor(object):

    #Constant used to adjust size
    k = 10.0

    projections = Proj()

    #Returns a marker that represents data.
    def getDot( self, state, county, year ):

        projection = proj.getProjections( state, county, year )

        #Size of marker.
        size = projection / k
        return size

    #Returns the county from the given fips and state code.
    def getCounty( self, state, fips, stateCode):     
        
        countyName= state.loc("FIPS")
        if fips !=510 & fips <190:
            return countyName[ state.index[(fips/2)+2],"COUNTY NAME"]
        if fips==186 & stateCode==24:
            return countyName[ state.index[((fips+1)/2)+2],"COUNTY NAME"]
        if fips>=190 & stateCode==24:
            return countyName[ state.index[((fips-2)/2)+2],"COUNTY NAME"]
        else:
            return countyName[ state.index[(fips/2)+2],"COUNTY NAME"]

    #Gets the Hispanic population of a county.
    def getHisp( self, state, fips, stateCode, year ):     
   
        #Get the row the fips column is in 
        countyName= state.loc("FIPS")
        if fips !=510 & fips<190:
            return self.projections.getProjections( state, index[(fips/2)+2], year )
        if fips==186 & stateCode==24:
            return self.projections.getProjections( state, index[((fips-2)/2)+2], year )
        if fips>=190 & stateCode==24:
            return self.projections.getProjections( state, index[((fips-2)/2)+2], year )
        else:
            return self.projections.getProjections( state, index[(fips/2)+2], year )
       