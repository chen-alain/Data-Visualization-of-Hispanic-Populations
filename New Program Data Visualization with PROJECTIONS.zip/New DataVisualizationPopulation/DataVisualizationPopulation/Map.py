"""
The Map class visualizes the data.
Alain Chen, CJ Phillips, Brett Woods
Created: Oct 15th, 2014
Last Edited: Dec 14th, 2014

We hereby certify that the program below represents our work 
and the design, content, and logic was completed without outside assistance.

"""
import logging
logging.basicConfig(level=logging.DEBUG)
import string as st
import bokeh
import pandas
import bokeh.server as bs
import Data as dt #Brings in our raw data
import DataProcessor as dtp #Brings in the functions that can interpret some of the proper data
import numpy as np #Brings in certain mathmateiccal functions.
from bokeh.sampledata import us_counties #Imports the county shapes.
from bokeh.plotting import * #imports all plotting functions
from random import randint #Random number generator. 
from bokeh.objects import HoverTool #Allows for information you can hover over
from bokeh.objects import Plot, ColumnDataSource, Range1d #Brings in the graphing tools

from collections import OrderedDict#Used to create a list sort of structure that can be sorted through by the hover tool
#Creates the map.
class Map(object):
    
    #Gets the states COde
    def getState(self, FIPS):
            
            nString=str(FIPS)#FIPS comes in as a list of strings. We need to fix that. 
            FIPSstring=nString.replace("(","")#Partitions the data to make it more readable.
            stateCountyCodes=FIPSstring.partition(",")
            stateCode=stateCountyCodes[0]
            if stateCode=="29":#The states are ordered alphabetically so the codes are different from the FIPS
                return 24
            else:
                return 15
    #Gets just the county code rather than the whole fips code.
    def getCountyCode(self, FIPS):
            nString=str(FIPS)#Fips comes in as a list of strings. we need to fix that. 
            FIPSstring=nString.replace(")","")#Partitions the data to make it more readable.
            stateCountyCodes=FIPSstring.partition(",")
            countyCode=stateCountyCodes[2]
            return int(countyCode)
    #Sets the colors of a county based on population.
    def setColor(self,hispPop):
        colors = ["#F1EEF6", "#D4B9DA", "#C994C7", "#DF65B0", "#DD1C77", "#980043"]
        if hispPop <= 500:
            return colors[0]
        elif (hispPop > 500) & (hispPop <=2000):
            return colors[1]
        elif (hispPop > 2000) & (hispPop <=4000):
            return colors[2]
        elif (hispPop > 4000) & (hispPop <=6000):
            return colors[3]
        elif (hispPop > 6000) & (hispPop <=8000):
            return colors[4]
        else:
            return colors[5]
    #Creates the Map
    def createMap(self):
       
        #Pulls the raw Data for mapping the counties
        county_xs=[
            us_counties.data[code]['lons'] for code in us_counties.data
            if us_counties.data[code]['state'] in ('mo','ks')
        ] 
        county_ys=[
            us_counties.data[code]['lats'] for code in us_counties.data
            if us_counties.data[code]['state'] in ('mo','ks') 
        ]
        colors = ["#F1EEF6", "#D4B9DA", "#C994C7", "#DF65B0", "#DD1C77", "#980043"]
        mDP=dtp.DataProcessor() #Creates a data processing object.
        mData=dt.Data() #Creates a data object.
        county_colors=[]#Holds the colors for each county 
        
        ids=[]#Holds the counties FIPS codes.
        agencies=[]#Holds the list of agencies. A lost ideal in the current implementation.
        countyNames=[]#Holds the county names.
        hispPops=[] #Holds the hispanic populations.
        for county_id in us_counties.data:
            if us_counties.data[county_id]['state'] !='mo' and us_counties.data[county_id]['state'] != 'ks':
                continue
            try:
                      
                #print county_id               
                stateCode=self.getState(county_id)
                cName=mDP.getCounty(mData.stateData[stateCode],self.getCountyCode(county_id),stateCode)#Gets county Name from a series of functions we wrote
                hispPop=int(mDP.getHisp(mData.stateData[stateCode],self.getCountyCode(county_id),stateCode, 2010)) #!!!NEW should get projections.
                color=self.setColor(hispPop)   
                ids.append(county_id)
                countyNames.append(cName)
                county_colors.append(color)
                hispPops.append(hispPop)
            except:
                county_colors.append("black")#Takes into account possible errors.

        countyNames.insert(33,"St.Louis City")#Takes into account St.Louis City, which has an outlier fips code of 510.
        ids.insert(33,"29,510")
        hispPops.insert(33,11913)
        county_colors[33]="#980043"

        countyNames[12]=countyNames[198] #Reassigns Ste. Genevieve
        ids[12]=ids[198]
        county_colors[12]=county_colors[198]
        hispPops[12]=hispPops[198]

        countyNames[198]=countyNames[136] # Reassigns St.Francois
        ids[198]=ids[136]
        county_colors[198]=county_colors[136]
        hispPops[198]=hispPops[136]

        countyNames[136]="St.Louis County" # Reassigns St. Louis County
        ids[136]=("29,189")
        county_colors[136]="#980043"
        hispPops[136]=25024

        source = ColumnDataSource(
            data=dict(
                color=county_colors,
                fips=ids,
                name=countyNames,
                Hispanics=hispPops,
            )
        )

        TOOLS=("pan,wheel_zoom,box_zoom,reset,hover,previewsave")#finds what tools for the graph to use
        output_file("moplot.html",title="Hispanics")#Sends the graph out in html
        
        
        patches(county_xs,county_ys,source=source, fill_color=county_colors,fill_alpha=0.7,tools=TOOLS,line_color="black",line_width=0.5, title="Hispanics")
        hover=curplot().select(dict(type=HoverTool))#establishes the hovering functions

        hover.tooltips=OrderedDict([
           ("index","$index"), ("fips","@fips"),("name","@name"),("Hispanics","@Hispanics")])#writes the tooltips
        hold()#Keeps the plot.
        show()#Displays the map.
        return 0
   
       

