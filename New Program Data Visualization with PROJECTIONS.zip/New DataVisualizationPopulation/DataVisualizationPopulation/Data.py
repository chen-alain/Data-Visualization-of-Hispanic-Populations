"""
The Data class stores the data that is loaded from US Census files.
Alain Chen, CJ Phillips, Brett Woods
Created: Oct 15th, 2014
Last Edited: Dec 14th, 2014

We hereby certify that the program below represents our work 
and the design, content, and logic was completed without outside assistance.
"""

import pandas as pd
import csv

class Data(object):
    
    #List that stores the 50 state file names.
    stateName = []

    #List that would store data frames of state data.
    stateData = []

    #List that stores the file names for codes for ZIP and FIPS.
    zipName = []

    #Structure that stores the raw data to convert ZIP to FIPS.
    zipFrame = []

    #Structure that stores the organized data to convert ZIP to FIPS.
    zipData = []


    #Initialize.
    def __init__(self):
        self.stateName = [ 'Data/Alabama.csv', 'Data/Alaska.csv', 'Data/Arizona.csv', 'Data/Arkansas.csv', \
                'Data/California.csv', 'Data/Colorado.csv', 'Data/Connecticut.csv', \
                'Data/Delaware.csv', 'Data/Florida.csv', 'Data/Georgia.csv', 'Data/Hawaii.csv', \
                'Data/Idaho.csv', 'Data/Illinois.csv', 'Data/Indiana.csv', 'Data/Iowa.csv', \
                'Data/Kansas.csv', 'Data/Kentucky.csv', 'Data/Louisiana.csv', 'Data/Maine.csv', \
                'Data/Maryland.csv', 'Data/Massachusetts.csv', 'Data/Michigan.csv', 'Data/Minnesota.csv', \
                'Data/Mississippi.csv', 'Data/Missouri.csv', 'Data/Montana.csv', 'Data/Nebraska.csv', \
                'Data/Nevada.csv', 'Data/New Hampshire.csv', 'Data/New Jersey.csv', 'Data/New Mexico.csv', \
                'Data/New York.csv', 'Data/North Carolina.csv', 'Data/North Dakota.csv', \
                'Data/Ohio.csv', 'Data/Oklahoma.csv', 'Data/Oregon.csv', 'Data/Pennsylvania.csv', \
                'Data/Rhode Island.csv', 'Data/South Carolina.csv', 'Data/South Dakota.csv', \
                'Data/Tennessee.csv', 'Data/Texas.csv', 'Data/Utah.csv', 'Data/Vermont.csv', \
                'Data/Virginia.csv', 'Data/Washington.csv', 'Data/West Virginia.csv', \
                'Data/Wisconsin.csv', 'Data/Wyoming.csv', 'Data/District of Columbia.csv' ]
        self.zipName = [ 'ZIP/KansasZIP.csv', 'ZIP/MissouriZIP.csv' ]
        self.putInDataFrame()

    #Put the data inside the 50 state files into 50 different data frames.
    def putInDataFrame(self):
        for state in self.stateName:
            self.stateData.append( pd.DataFrame.from_csv(state) )
        for state in self.zipName:
            self.zipFrame.append( pd.DataFrame.from_csv(state) )

    #Get FIPS from the given ZIP code. ZIP is an int.
    def getFIPS( self, zip ):

        #Change from nine digit ZIP to five digit if necessary.
        zipCorrected = zip
        if zipCorrected > 99999:
            zipCorrected = int( zipCorrected / 10000 )

        #The ZIP is in Kansas.
        for i in range( 0, len( self.zipFrame[0] ) ):
            if self.zipFrame[0].index[i] == zipCorrected:
                return self.zipFrame[0].get_values()[i][0] - 20000

        #The ZIP is in Missouri.
        for i in range( 0, len( self.zipFrame[1] ) ):
            if self.zipFrame[1].index[i] == zipCorrected:
                return self.zipFrame[1].get_values()[i][0] - 29000

        #Return error if ZIP is not valid.
        return -1

