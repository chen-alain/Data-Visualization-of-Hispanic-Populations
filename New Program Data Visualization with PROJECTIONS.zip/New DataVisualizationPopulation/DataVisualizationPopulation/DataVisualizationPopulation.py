"""
This program visualizes and predicts Hispanic populations 
from the 2010 US Census.

Alain Chen, CJ Phillips, Brett Woods
Created: Oct 15th, 2014
Last Edited: Dec 14th, 2014

We hereby certify that the program below represents our work 
and the design, content, and logic was completed without outside assistance.
"""

import Data as dt
import DataProcessor as dtp
import Projections as proj
import Agency as ag
import pandas as pd 
import Map as mp
data = dt.Data()

pro = proj.Projections()

agencies = ag.Agency()

dataP = dtp.DataProcessor()

newMap=mp.Map()
newMap.createMap()
